# Ionic 4, Angular 7 and Cordova Tutorial: Build CRUD Mobile Apps

This source code is part of [Ionic 4, Angular 7 and Cordova Tutorial: Build CRUD Mobile Apps](https://www.djamware.com/post/5be52ce280aca72b942e31bc/ionic-4-angular-7-and-cordova-tutorial-build-crud-mobile-apps) tutorial.
